QTouch Modular Library Release 
===============================
QTouch Library is a royalty-free software library for developing touch applications using micro-controllers with Peripheral touch controller.

Please refer the QTouch Modular Library Userguide available in the link below for further information.
http://www.atmel.com/Images/Atmel-42805-QTouch-Modular-Library-Peripheral-Touch-Controller_User-Guide.pdf
