#include <atmel_start.h>
#include "led_driver.h"
#include <math.h>
extern volatile uint8_t measurement_done_touch;


uint8_t bt;
int prev[4],current[4];
int status[4],scroller[3],SliderData[3],p[3],c[3];
uint16_t rgb_data;

int button_led[4]={128,64,32,16};
int slider_led[8]={128,192,224,240,248,252,254,255};
#define LED_OFF 0


int main(void)
{
	/* Initializes MCU, drivers and middle ware */
	atmel_start_init();
	#if ENABLE_LED== 1u
	init_led_driver();
	led_reset();
	#endif

	/* Replace with your application code */
	while (1)
	{
		touch_process();
		rgb_button(0);
		rgb_button(1);
		rgb_button(2);
		rgb_button(3);
	}
}


uint8_t button(int i)
{
	uint8_t button_value = 0;
	if(i==0)
	{
		button_value=0x01;
		//red button is ON;
	}
	else if(i==1)
	{
		button_value=0x02;
		//green button is ON;
	}
	else if(i==2)
	{
		button_value=0x03;
		//blue button is ON;
	}
	return button_value;
}


void rgb_button(int i)
{
	uint8_t b1 = get_sensor_state(i) & KEY_TOUCHED_MASK;
	if(b1!=0)
	{
		bt = button(i);
		prev[i]=current[i];
		current[i]=1;
	}
	else
	{
		current[i]=0;
	}
	if(prev[i]==0 && current[i]==1)
	{
		touch_detected(i);
	}
	else if(prev[i]==1 && current[i]==0)
	{
		released_touch(i);
	}
	if(bt==0x01 && i==0)
	{
		slider(i);
	}
	else if(bt==0x02 && i==1)
	{
		slider(i);
	}
	else if(bt==0x03 && i==2)
	{
		slider(i);
	}
}

void slider(int i)
{
	p[i]=c[i];
	slider_status(i);
	if(p[i]!=c[i])
	{
		if((p[i]==4)&&(c[i]==1))
		{
			c[i]=p[i]+1;
		}
		if((p[i]==1)&&(c[i]==4))
		{
			p[i]=c[i]+1;
		}
		inc_dec(c[i],p[i],i);
	}
}


void slider_status(int i)
{
	for (uint8_t k=4, j=1; k<8; k++,j++)
	{
		if(0u!=(get_sensor_state(k) & KEY_TOUCHED_MASK))
		{
			c[i]=j;
		}
	}
}

void inc_dec(int current,int prev,int i)
{
	uint8_t value=1,value1=128,slider_stat=0;
	int shift,x=0;
	SliderData[i]=x;
	if((current>prev))
	{
		if((prev==4)&&(current==5))
		{
			current=1;
			c[i]=1;
			p[i]=0;
		}
		shift=current-1;
		if(scroller[i]>=240)
		{
			shift=shift+4;
		}
		slider_stat=value << shift;
	}
	else if((current<prev))
	{
		if((prev==5)&&(current==4))
		{
			current=4;
			c[i]=4;
			p[i]=0;
		}
		shift=3-(current-1);
		if(scroller[i]<=248)
		{
			shift=shift+4;
		}
		slider_stat=value1 >> shift;
	}
	if(slider_stat>0)
	{
		x=log(slider_stat)/log(2);
		led_gpio_update(slider_led[x],LED_SCROLLER);
		if(bt==0x01 && i==0)
		{
			scroller[i]=slider_led[x];
			rgb_data=rgb_data & 0xF0FF;
			rgb_data=rgb_data|((x+1)<<8);
		}
		else if(bt==0x02 && i==1)
		{
			scroller[i]=slider_led[x];
			rgb_data=rgb_data & 0xFF0F;
			rgb_data=rgb_data|((x+1)<<4);
		}
		else if(bt==0x03 && i==2)
		{
			scroller[i]=slider_led[x];
			rgb_data=rgb_data & 0xFFF0;
			rgb_data=rgb_data|(x+1);
		}
	}
	if(SliderData[i]!=(x+1))
	{
		printf("B_On:0x%3x\r\n",rgb_data);
		SliderData[i]=x+1;
	}

}



void touch_detected(int i)
{
	if(status[i]%2==0)
	{
		led_gpio_update(LED_OFF,LED_BUTTON);
		led_gpio_update(LED_OFF,LED_SCROLLER);
	}
	else
	{
		rgb_data=rgb_data & 0x0FFF;
		rgb_data=rgb_data|((i+1)<<12);
		printf("B_On:0x%3x\r\n",rgb_data);
		led_gpio_update(button_led[i],LED_BUTTON);
		if(i<3)
		led_gpio_update(scroller[i], LED_SCROLLER);
	}
}

void released_touch(int i)
{
	status[i]++;
	prev[i]=0;
	current[i]=0;
}

